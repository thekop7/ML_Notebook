Objectives
In this hands-on lab, you will learn how to:

Use Pandas to identify columns in a dataset with missing values
Use Pandas to replace missing values with real values
Use Pandas to filter columns in a dataset
Use Pandas to quantize values in a column
Use Pandas to create indicator columns representing categorical data